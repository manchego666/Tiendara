﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Tiendara.CapaDatos.Entidades;

namespace Tiendara.CapaSql
{
    public interface ISqlMigrador
    {
        void CrearBaseDeDatos(string nombre, string connectionString);
        void CrearTodasLasTablas(); // Llama internamente a las migraciones

        void InsertarProducto(Producto producto);
        void ActualizarProducto(Producto producto);
        void EliminarProducto(Guid productoId);
        List<Producto> ConsultarProductos();

        // Más métodos para Inventario, Usuario, etc.
    }
}