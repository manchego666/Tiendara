﻿using System.Data.SqlClient;

namespace Tiendara.CapaSql.Migraciones;

public static class TablaProductoMigracion
{
    public static void Crear(SqlConnection conn)
    {
        var query = @"
        IF OBJECT_ID('Producto', 'U') IS NULL
        BEGIN
            CREATE TABLE Producto (
                Id UNIQUEIDENTIFIER PRIMARY KEY,
                SKU NVARCHAR(50) NOT NULL,
                CodigoBarras NVARCHAR(100) NOT NULL,
                Nombre NVARCHAR(100) NOT NULL,
                Marca NVARCHAR(100) NOT NULL,
                Categoria INT NOT NULL,
                UnidadVenta INT NOT NULL,
                PrecioBase DECIMAL(18,2) NOT NULL,
                TasaImpuesto DECIMAL(5,2) NOT NULL,
                EsPesable BIT NOT NULL,
                EsPerecedero BIT NOT NULL
            )
        END";

        using var cmd = new SqlCommand(query, conn);
        cmd.ExecuteNonQuery();
    }
}
