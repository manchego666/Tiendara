﻿using System.Data.SqlClient;
using Tiendara.CapaDatos.Entidades;
using Tiendara.CapaSql.Migraciones;
using Tiendara.CapaSql.UtilidadesSql;
using System.Data.SqlClient;

namespace Tiendara.CapaSql;

public class SqlMigrador : ISqlMigrador
{
    private readonly ConfiguracionSql _config;

    public SqlMigrador(ConfiguracionSql config)
    {
        _config = config;
    }

    public void CrearBaseDeDatos(string nombre, string connectionString)
    {
        var crearDbQuery = $@"
            IF NOT EXISTS (SELECT name FROM sys.databases WHERE name = N'{nombre}')
            BEGIN
                CREATE DATABASE [{nombre}]
            END";

        using var conn = new SqlConnection(connectionString);
        conn.Open();

        using var cmd = new SqlCommand(crearDbQuery, conn);
        cmd.ExecuteNonQuery();
    }

    public void CrearTodasLasTablas()
    {
        using var conn = new SqlConnection(_config.GetConnectionString());
        conn.Open();

        TablaProductoMigracion.Crear(conn);
        TablaInventarioMigracion.Crear(conn);
        // Agrega más migraciones aquí
    }

    public void InsertarProducto(Producto producto)
    {
        using var conn = new SqlConnection(_config.GetConnectionString());
        conn.Open();

        var query = @"INSERT INTO Producto 
            (Id, SKU, CodigoBarras, Nombre, Marca, Categoria, UnidadVenta, PrecioBase, TasaImpuesto, EsPesable, EsPerecedero)
            VALUES 
            (@Id, @SKU, @CodigoBarras, @Nombre, @Marca, @Categoria, @UnidadVenta, @PrecioBase, @TasaImpuesto, @EsPesable, @EsPerecedero)";

        using var cmd = new SqlCommand(query, conn);
        cmd.Parameters.AddWithValue("@Id", producto.Id);
        cmd.Parameters.AddWithValue("@SKU", producto.SKU);
        cmd.Parameters.AddWithValue("@CodigoBarras", producto.CodigoBarras);
        cmd.Parameters.AddWithValue("@Nombre", producto.Nombre);
        cmd.Parameters.AddWithValue("@Marca", producto.Marca);
        cmd.Parameters.AddWithValue("@Categoria", (int)producto.Categoria);
        cmd.Parameters.AddWithValue("@UnidadVenta", (int)producto.UnidadVenta);
        cmd.Parameters.AddWithValue("@PrecioBase", producto.PrecioBase);
        cmd.Parameters.AddWithValue("@TasaImpuesto", producto.TasaImpuesto);
        cmd.Parameters.AddWithValue("@EsPesable", producto.EsPesable);
        cmd.Parameters.AddWithValue("@EsPerecedero", producto.EsPerecedero);

        cmd.ExecuteNonQuery();
    }

    public void ActualizarProducto(Producto producto)
    {
        using var conn = new SqlConnection(_config.GetConnectionString());
        conn.Open();

        var query = @"UPDATE Producto SET 
            SKU = @SKU,
            CodigoBarras = @CodigoBarras,
            Nombre = @Nombre,
            Marca = @Marca,
            Categoria = @Categoria,
            UnidadVenta = @UnidadVenta,
            PrecioBase = @PrecioBase,
            TasaImpuesto = @TasaImpuesto,
            EsPesable = @EsPesable,
            EsPerecedero = @EsPerecedero
            WHERE Id = @Id";

        using var cmd = new SqlCommand(query, conn);
        cmd.Parameters.AddWithValue("@Id", producto.Id);
        cmd.Parameters.AddWithValue("@SKU", producto.SKU);
        cmd.Parameters.AddWithValue("@CodigoBarras", producto.CodigoBarras);
        cmd.Parameters.AddWithValue("@Nombre", producto.Nombre);
        cmd.Parameters.AddWithValue("@Marca", producto.Marca);
        cmd.Parameters.AddWithValue("@Categoria", (int)producto.Categoria);
        cmd.Parameters.AddWithValue("@UnidadVenta", (int)producto.UnidadVenta);
        cmd.Parameters.AddWithValue("@PrecioBase", producto.PrecioBase);
        cmd.Parameters.AddWithValue("@TasaImpuesto", producto.TasaImpuesto);
        cmd.Parameters.AddWithValue("@EsPesable", producto.EsPesable);
        cmd.Parameters.AddWithValue("@EsPerecedero", producto.EsPerecedero);

        cmd.ExecuteNonQuery();
    }

    public void EliminarProducto(Guid productoId)
    {
        using var conn = new SqlConnection(_config.GetConnectionString());
        conn.Open();

        var query = "DELETE FROM Producto WHERE Id = @Id";

        using var cmd = new SqlCommand(query, conn);
        cmd.Parameters.AddWithValue("@Id", productoId);
        cmd.ExecuteNonQuery();
    }

    public List<Producto> ConsultarProductos()
    {
        var lista = new List<Producto>();

        using var conn = new SqlConnection(_config.GetConnectionString());
        conn.Open();

        var query = "SELECT * FROM Producto";

        using var cmd = new SqlCommand(query, conn);
        using var reader = cmd.ExecuteReader();

        while (reader.Read())
        {
            var p = new Producto
            {
                Id = reader.GetGuid(reader.GetOrdinal("Id")),
                SKU = reader.GetString(reader.GetOrdinal("SKU")),
                CodigoBarras = reader.GetString(reader.GetOrdinal("CodigoBarras")),
                Nombre = reader.GetString(reader.GetOrdinal("Nombre")),
                Marca = reader.GetString(reader.GetOrdinal("Marca")),
                Categoria = (CategoriaProducto)reader.GetInt32(reader.GetOrdinal("Categoria")),
                UnidadVenta = (UnidadVenta)reader.GetInt32(reader.GetOrdinal("UnidadVenta")),
                PrecioBase = reader.GetDecimal(reader.GetOrdinal("PrecioBase")),
                TasaImpuesto = reader.GetDecimal(reader.GetOrdinal("TasaImpuesto")),
                EsPesable = reader.GetBoolean(reader.GetOrdinal("EsPesable")),
                EsPerecedero = reader.GetBoolean(reader.GetOrdinal("EsPerecedero"))
            };
            lista.Add(p);
        }

        return lista;
    }
}
